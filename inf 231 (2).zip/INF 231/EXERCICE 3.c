#include <stdio.h>
#include <stdlib.h>

// Définition d'un nœud de liste doublement chaînée
typedef struct DNode {
    int data;
    struct DNode* prev;
    struct DNode* next;
} DNode;

// Insertion triée
void insererTrieD(DNode** head, int valeur) {
    DNode* nouveau = (DNode*)malloc(sizeof(DNode));
    nouveau->data = valeur;
    nouveau->prev = nouveau->next = NULL;

    // Cas 1 : liste vide ou insertion avant le premier élément
    if (*head == NULL || (*head)->data >= valeur) {
        nouveau->next = *head;
        if (*head != NULL) (*head)->prev = nouveau;
        *head = nouveau;
        return;
    }

    // Cas 2 : trouver la bonne position
    DNode* temp = *head;
    while (temp->next != NULL && temp->next->data < valeur) {
        temp = temp->next;
    }

    nouveau->next = temp->next;
    if (temp->next != NULL) temp->next->prev = nouveau;
    temp->next = nouveau;
    nouveau->prev = temp;
}

// Affichage de la liste doublement chaînée
void afficherD(DNode* head) {
    DNode* temp = head;
    printf("Liste : ");
    while (temp != NULL) {
        printf("%d <-> ", temp->data);
        temp = temp->next;
    }
    printf("NULL\n");
}

int main() {
    DNode* liste = NULL;

    insererTrieD(&liste, 40);
    insererTrieD(&liste, 20);
    insererTrieD(&liste, 10);
    insererTrieD(&liste, 30);
    insererTrieD(&liste, 50);

    printf("Après insertion triée :\n");
    afficherD(liste);

    return 0;
}
