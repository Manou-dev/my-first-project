#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int data;
    struct Node* next;
} Node;

void supprimerOccurences(Node** head, int valeur) {
    Node* temp = *head;
    Node* prev = NULL;

    while (temp != NULL) {
        if (temp->data == valeur) {
            if (prev == NULL) { // cas tête
                *head = temp->next;
                free(temp);
                temp = *head;
            } else {
                prev->next = temp->next;
                free(temp);
                temp = prev->next;
            }
        } else {
            prev = temp;
            temp = temp->next;
        }
    }
}

void insererEnTete(Node** head, int valeur) {
    Node* nouveau = (Node*)malloc(sizeof(Node));
    nouveau->data = valeur;
    nouveau->next = *head;
    *head = nouveau;
}

void afficherListe(Node* head) {
    Node* temp = head;
    while (temp != NULL) {
        printf("%d -> ", temp->data);
        temp = temp->next;
    }
    printf("NULL\n");
}

int main() {
    Node* liste = NULL;

    // Créons une liste: 3 -> 5 -> 3 -> 7 -> 3 -> NULL
    insererEnTete(&liste, 3);
    insererEnTete(&liste, 7);
    insererEnTete(&liste, 3);
    insererEnTete(&liste, 5);
    insererEnTete(&liste, 3);

    printf("Liste avant suppression:\n");
    afficherListe(liste);

    supprimerOccurences(&liste, 3);

    printf("Liste après suppression des 3:\n");
    afficherListe(liste);

    return 0;
}
