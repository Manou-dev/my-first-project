#include <stdio.h>
#include <stdlib.h>

// Définition d'un nœud
typedef struct Node {
    int data;
    struct Node* next;
} Node;

// Insertion en tête (par rapport à tail)
void insererTeteCirc(Node** tail, int valeur) {
    Node* nouveau = (Node*)malloc(sizeof(Node));
    nouveau->data = valeur;

    if (*tail == NULL) {
        *tail = nouveau;
        nouveau->next = nouveau;
    } else {
        nouveau->next = (*tail)->next;
        (*tail)->next = nouveau;
    }
}

// Insertion en queue
void insererQueueCirc(Node** tail, int valeur) {
    insererTeteCirc(tail, valeur); // insère comme en tête
    *tail = (*tail)->next;         // avancer tail pour que ce soit la queue
}

// Affichage de la liste circulaire
void afficherCirc(Node* tail) {
    if (tail == NULL) {
        printf("Liste vide\n");
        return;
    }

    Node* temp = tail->next; // début = après tail
    do {
        printf("%d -> ", temp->data);
        temp = temp->next;
    } while (temp != tail->next);
    printf("(retour au début)\n");
}

int main() {
    Node* liste = NULL; // tail

    // Insertion en tête
    insererTeteCirc(&liste, 10);
    insererTeteCirc(&liste, 20);
    insererTeteCirc(&liste, 30);

    printf("Après insertion en tête:\n");
    afficherCirc(liste);

    // Insertion en queue
    insererQueueCirc(&liste, 40);
    insererQueueCirc(&liste, 50);

    printf("Après insertion en queue:\n");
    afficherCirc(liste);

    return 0;
}
