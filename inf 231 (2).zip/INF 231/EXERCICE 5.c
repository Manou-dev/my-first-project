#include <stdio.h>
#include <stdlib.h>

// Définition du nœud d'une liste doublement chaînée circulaire
typedef struct DNode {
    int data;
    struct DNode* prev;
    struct DNode* next;
} DNode;

// Insertion en tête
void insererTeteDCirc(DNode** head, int valeur) {
    DNode* nouveau = (DNode*)malloc(sizeof(DNode));
    nouveau->data = valeur;

    if (*head == NULL) { // Liste vide
        nouveau->next = nouveau->prev = nouveau;
        *head = nouveau;
    } else {
        DNode* last = (*head)->prev;
        nouveau->next = *head;
        nouveau->prev = last;
        last->next = nouveau;
        (*head)->prev = nouveau;
        *head = nouveau; // le nouvel élément devient la tête
    }
}

// Insertion en queue
void insererQueueDCirc(DNode** head, int valeur) {
    if (*head == NULL) {
        insererTeteDCirc(head, valeur);
    } else {
        DNode* nouveau = (DNode*)malloc(sizeof(DNode));
        nouveau->data = valeur;

        DNode* last = (*head)->prev;
        nouveau->next = *head;
        nouveau->prev = last;
        last->next = nouveau;
        (*head)->prev = nouveau;
    }
}

// Affichage de la liste doublement chaînée circulaire
void afficherDCirc(DNode* head) {
    if (head == NULL) {
        printf("Liste vide\n");
        return;
    }

    DNode* temp = head;
    printf("Liste : ");
    do {
        printf("%d <-> ", temp->data);
        temp = temp->next;
    } while (temp != head);
    printf("(retour au début)\n");
}

int main() {
    DNode* liste = NULL;

    // Insertion en tête
    insererTeteDCirc(&liste, 10);
    insererTeteDCirc(&liste, 20);
    insererTeteDCirc(&liste, 30);

    printf("Après insertion en tête :\n");
    afficherDCirc(liste);

    // Insertion en queue
    insererQueueDCirc(&liste, 40);
    insererQueueDCirc(&liste, 50);

    printf("Après insertion en queue :\n");
    afficherDCirc(liste);

    return 0;
}
