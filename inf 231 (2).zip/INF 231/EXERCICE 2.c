#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int data;
    struct Node* next;
} Node;

// Insertion triée
void insererTrie(Node** head, int valeur) {
    Node* nouveau = (Node*)malloc(sizeof(Node));
    nouveau->data = valeur;
    nouveau->next = NULL;

    if (*head == NULL || (*head)->data >= valeur) {
        nouveau->next = *head;
        *head = nouveau;
        return;
    }

    Node* temp = *head;
    while (temp->next != NULL && temp->next->data < valeur) {
        temp = temp->next;
    }
    nouveau->next = temp->next;
    temp->next = nouveau;
}

// Affichage
void afficherListe(Node* head) {
    Node* temp = head;
    while (temp != NULL) {
        printf("%d -> ", temp->data);
        temp = temp->next;
    }
    printf("NULL\n");
}

int main() {
    Node* liste = NULL;

    // Insertion d'éléments dans l'ordre trié
    insererTrie(&liste, 7);
    insererTrie(&liste, 3);
    insererTrie(&liste, 5);
    insererTrie(&liste, 10);
    insererTrie(&liste, 1);

    printf("Liste triée après insertions:\n");
    afficherListe(liste);

    return 0;
}
